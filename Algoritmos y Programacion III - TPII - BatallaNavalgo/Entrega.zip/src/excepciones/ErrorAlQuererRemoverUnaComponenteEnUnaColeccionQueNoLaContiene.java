package excepciones;

public class ErrorAlQuererRemoverUnaComponenteEnUnaColeccionQueNoLaContiene
		extends Exception {

}
