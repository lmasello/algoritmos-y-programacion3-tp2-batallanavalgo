package excepciones;

public class ValoresDeParametroFueraDeRango extends Exception {

}
