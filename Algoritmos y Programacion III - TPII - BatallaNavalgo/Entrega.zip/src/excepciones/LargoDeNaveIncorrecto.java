package excepciones;

public class LargoDeNaveIncorrecto extends Exception {

}
