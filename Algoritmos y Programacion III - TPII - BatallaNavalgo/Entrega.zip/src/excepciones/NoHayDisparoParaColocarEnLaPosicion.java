package excepciones;

public class NoHayDisparoParaColocarEnLaPosicion extends Exception {

}
