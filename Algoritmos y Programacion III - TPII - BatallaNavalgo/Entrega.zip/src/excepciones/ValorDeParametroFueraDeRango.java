package excepciones;

public class ValorDeParametroFueraDeRango extends Exception {

}
