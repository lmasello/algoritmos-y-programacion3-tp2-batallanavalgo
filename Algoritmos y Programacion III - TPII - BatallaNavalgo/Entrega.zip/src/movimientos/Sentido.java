package movimientos;

import componentesDeTablero.Posicion;

public interface Sentido {

	public abstract Sentido proximoSentido();
	/*Metodo que devuelve que seria el proximo sentido de movimiento al sentido actual*/
}
